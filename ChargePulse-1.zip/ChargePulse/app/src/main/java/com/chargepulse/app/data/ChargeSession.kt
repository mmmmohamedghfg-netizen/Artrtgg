package com.chargepulse.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sessions")
data class ChargeSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startTime: Long,
    var endTime: Long? = null,
    val startPercent: Int,
    var endPercent: Int? = null,
    var avgWatts: Double = 0.0,
    var peakWatts: Double = 0.0,
    var maxTemp: Double = 0.0,
    var chargerName: String? = null
)
