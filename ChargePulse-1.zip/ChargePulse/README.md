# Charge Pulse

تطبيق أندرويد لمراقبة سرعة الشحن مع واجهة Compose عربية RTL وثيم AMOLED.

## البناء
```bash
gradle -p "build-dir/ChargePulse" assembleDebug --no-daemon
```
