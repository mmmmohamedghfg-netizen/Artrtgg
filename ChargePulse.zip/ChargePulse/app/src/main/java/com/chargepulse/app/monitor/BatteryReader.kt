package com.chargepulse.app.monitor

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import java.io.File

object BatteryReader {

    fun read(context: Context): BatterySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatterySnapshot()

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: ""

        var microAmps = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val bm = context.getSystemService(BatteryManager::class.java)
            if (bm != null) microAmps = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        }
        if (microAmps == 0 || microAmps == Int.MIN_VALUE) {
            readSysfs("/sys/class/power_supply/battery/current_now")?.let { microAmps = it }
        }

        val safeMicroAmps = if (microAmps == Int.MIN_VALUE) 0 else microAmps
        val milliAmps = kotlin.math.abs(safeMicroAmps.toLong()) / 1000.0
        val volts = voltageMv / 1000.0
        val percent = if (scale > 0 && level >= 0) level * 100.0 / scale else 0.0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING && plugged != 0
        val full = status == BatteryManager.BATTERY_STATUS_FULL
        val watts = if (charging) volts * milliAmps / 1000.0 else 0.0

        return BatterySnapshot(
            percent = percent,
            voltage = volts,
            currentMa = milliAmps,
            temperature = temp / 10.0,
            charging = charging,
            full = full,
            plugged = plugged,
            status = status,
            health = health,
            technology = tech,
            chargeCounterUah = chargeCounter(context),
            watts = watts
        )
    }

    private fun chargeCounter(context: Context): Long {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return -1
        val bm = context.getSystemService(BatteryManager::class.java) ?: return -1
        val value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        return if (value == Int.MIN_VALUE) -1 else value.toLong()
    }

    private fun readSysfs(path: String): Int? = try {
        File(path).readText().trim().toIntOrNull()
    } catch (e: Exception) { null }
}

data class BatterySnapshot(
    val percent: Double = 0.0,
    val voltage: Double = 0.0,
    val currentMa: Double = 0.0,
    val temperature: Double = 0.0,
    val charging: Boolean = false,
    val full: Boolean = false,
    val plugged: Int = 0,
    val status: Int = -1,
    val health: Int = -1,
    val technology: String = "",
    val chargeCounterUah: Long = -1,
    val watts: Double = 0.0
)
