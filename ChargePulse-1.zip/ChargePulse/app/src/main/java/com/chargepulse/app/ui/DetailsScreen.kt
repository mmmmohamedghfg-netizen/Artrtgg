package com.chargepulse.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chargepulse.app.monitor.MonitorRepository
import java.util.Locale

@Composable
fun DetailsScreen(onBack: () -> Unit) {
    val state by MonitorRepository.state.collectAsState()
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("رجوع") }
        Spacer(Modifier.height(8.dp))
        Text("المزيد من المعلومات", color = Color.White, fontSize = 24.sp)
        Spacer(Modifier.height(16.dp))

        DetailRow("نوع الشاحن", chargerName(state.plugged))
        DetailRow("تقنية البطارية", state.technology.ifEmpty { "غير معروف" })
        DetailRow("صحة البطارية", healthName(state.health))
        DetailRow("التيار", String.format(Locale.US, "%.0f mA", state.currentMa))
        DetailRow(
            "السعة الحالية",
            if (state.chargeCounterUah > 0)
                String.format(Locale.US, "%.0f mAh", state.chargeCounterUah / 1000.0) else "--"
        )
        DetailRow("السعة التصميمية", "--")
        DetailRow("عدد دورات الشحن", "--")
        DetailRow("أعلى قدرة في الجلسة", String.format(Locale.US, "%.2f W", state.sessionPeakW))
        DetailRow("متوسط القدرة", String.format(Locale.US, "%.2f W", state.sessionAvgW))
    }
}

@Composable
fun DetailRow(title: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Color(0xFF9AA4B2), fontSize = 16.sp)
        Text(value, color = Color.White, fontSize = 16.sp)
    }
}

fun chargerName(plugged: Int): String = when (plugged) {
    1 -> "شاحن كهربائي"
    2 -> "USB"
    4 -> "شحن لاسلكي"
    8 -> "قاعدة شحن"
    else -> "غير معروف"
}

fun healthName(health: Int): String = when (health) {
    2 -> "جيدة"
    3 -> "سخونة"
    4 -> "تالفة"
    5 -> "جهد زائد"
    6 -> "باردة"
    else -> "غير معروف"
}
