package com.chargepulse.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BatteryGauge(percent: Double, accent: Color, modifier: Modifier = Modifier) {
    val animated by animateFloatAsState(targetValue = percent.toFloat(), label = "gauge")
    Canvas(modifier = modifier) {
        val stroke = 26f
        val inset = stroke
        val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
        drawArc(
            color = Color(0xFF1E1E24),
            startAngle = 135f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = arcSize,
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        val sweep = 270f * (animated / 100f)
        drawArc(
            color = accent,
            startAngle = 135f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = arcSize,
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        val angle = Math.toRadians((135 + sweep - 90).toDouble())
        val radius = size.minDimension / 2f - stroke
        val center = Offset(size.width / 2f, size.height / 2f)
        drawCircle(
            color = accent,
            radius = 12f,
            center = Offset(
                center.x + radius * cos(angle).toFloat(),
                center.y + radius * sin(angle).toFloat()
            )
        )
    }
}
