package com.chargepulse.app.ui

import android.app.Activity
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chargepulse.app.monitor.MonitorRepository
import com.chargepulse.app.ui.components.BatteryGauge
import com.chargepulse.app.ui.components.LiveChart
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    onDetails: () -> Unit,
    onHistory: () -> Unit,
    onChargers: () -> Unit,
    onSettings: () -> Unit
) {
    val state by MonitorRepository.state.collectAsState()
    val context = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var torchOn by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val timeFormat = remember { SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar", "EG")) }
        val timeText = remember(now) { timeFormat.format(Date(now)) }

        Text(timeText, color = Color.White, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))

        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(280.dp)) {
            BatteryGauge(percent = state.percent, accent = Color(0xFFFF2D55), modifier = Modifier.fillMaxSize())
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("⚡", color = Color.White, fontSize = 40.sp)
                Text(
                    String.format(Locale("ar", "EG"), "%.2f%%", state.percent),
                    color = Color.White,
                    fontSize = 34.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    when {
                        state.full -> stringResource(R.string.full)
                        state.charging && state.watts >= 18 -> stringResource(R.string.fast)
                        state.charging && state.watts >= 10 -> stringResource(R.string.normal)
                        state.charging -> stringResource(R.string.slow)
                        else -> stringResource(R.string.not_charging)
                    },
                    color = Color(0xFFFF4D8D),
                    fontSize = 16.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InfoCard(
                title = stringResource(R.string.time_left),
                value = if (state.estimateMinutes > 0)
                    String.format(Locale("ar", "EG"), "%.0f د", state.estimateMinutes) else "--",
                modifier = Modifier.weight(1f)
            )
            InfoCard(
                title = stringResource(R.string.voltage),
                value = String.format(Locale.US, "%.2f V", state.voltage),
                modifier = Modifier.weight(1f)
            )
            InfoCard(
                title = stringResource(R.string.temperature),
                value = String.format(Locale.US, "%.1f°C", state.temperature),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))

        LiveChart(values = state.history, accent = Color(0xFFFF2D55), modifier = Modifier
            .fillMaxWidth()
            .height(120.dp))

        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = onDetails) { Text(stringResource(R.string.details)) }
            TextButton(onClick = onHistory) { Text(stringResource(R.string.history)) }
            TextButton(onClick = onChargers) { Text(stringResource(R.string.chargers)) }
            TextButton(onClick = onSettings) { Text(stringResource(R.string.settings)) }
        }

        Spacer(Modifier.weight(1f))

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                val cam = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cam.cameraIdList.firstOrNull {
                    cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                id?.let { cam.setTorchMode(it, !torchOn); torchOn = !torchOn }
            }) { Text("🔦", fontSize = 24.sp) }

            Text(
                String.format(Locale.US, "%.2f W", state.watts),
                color = Color.White,
                fontSize = 32.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            IconButton(onClick = {
                val cam = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cam.cameraIdList.firstOrNull()
                id?.let {
                    val intent = android.content.Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                    context.startActivity(intent)
                }
            }) { Text("📷", fontSize = 24.sp) }
        }

        if (state.slowWarning) {
            Text(
                stringResource(R.string.slow_warning),
                color = Color(0xFFFFB300),
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun InfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0B0F))
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Color(0xFF9AA4B2), fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 18.sp)
        }
    }
}
