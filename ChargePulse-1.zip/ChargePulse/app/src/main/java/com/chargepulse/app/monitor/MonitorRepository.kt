package com.chargepulse.app.monitor

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class ChargeUiState(
    val percent: Double = 0.0,
    val watts: Double = 0.0,
    val voltage: Double = 0.0,
    val currentMa: Double = 0.0,
    val temperature: Double = 0.0,
    val charging: Boolean = false,
    val full: Boolean = false,
    val plugged: Int = 0,
    val status: Int = -1,
    val health: Int = -1,
    val technology: String = "",
    val chargeCounterUah: Long = -1,
    val sessionStart: Long = 0L,
    val sessionEnergyWh: Double = 0.0,
    val sessionPeakW: Double = 0.0,
    val sessionAvgW: Double = 0.0,
    val estimateMinutes: Double = 0.0,
    val slowWarning: Boolean = false,
    val history: List<Double> = emptyList()
)

object MonitorRepository {
    private val _state = MutableStateFlow(ChargeUiState())
    val state: StateFlow<ChargeUiState> = _state

    fun update(transform: (ChargeUiState) -> ChargeUiState) {
        _state.value = transform(_state.value)
    }
}
