package com.chargepulse.app.ui

import android.app.Activity
import android.content.Context
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chargepulse.app.monitor.MonitorRepository

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var keepOn by remember { mutableStateOf(prefs.getBoolean("keep_on", false)) }
    var dim by remember { mutableStateOf(prefs.getBoolean("dim", false)) }
    var lock by remember { mutableStateOf(prefs.getBoolean("lock", false)) }
    var threshold by remember { mutableStateOf(prefs.getInt("alert_percent", 80).toFloat()) }
    var dynamic by remember { mutableStateOf(prefs.getBoolean("dynamic", false)) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("رجوع") }
        Text("الإعدادات", color = Color.White, fontSize = 24.sp)
        Spacer(Modifier.height(16.dp))

        SettingSwitch("إبقاء الشاشة مضاءة", keepOn) {
            keepOn = it
            prefs.edit().putBoolean("keep_on", it).apply()
            (context as? Activity)?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        SettingSwitch("خفض السطوع تلقائيًا", dim) {
            dim = it
            prefs.edit().putBoolean("dim", it).apply()
        }

        SettingSwitch("وضع ملء الشاشة أثناء الشحن", lock) {
            lock = it
            prefs.edit().putBoolean("lock", it).apply()
        }

        SettingSwitch("ألوان النظام", dynamic) {
            dynamic = it
            prefs.edit().putBoolean("dynamic", it).apply()
        }

        Spacer(Modifier.height(16.dp))
        Text("تنبيه عند نسبة", color = Color.White, fontSize = 16.sp)
        Slider(
            value = threshold,
            onValueChange = {
                threshold = it
                prefs.edit().putInt("alert_percent", it.toInt()).apply()
            },
            valueRange = 50f..100f
        )
        Text(
            String.format(java.util.Locale.US, "%d%%", threshold.toInt()),
            color = Color.White
        )

        Spacer(Modifier.height(16.dp))
        Text("نصائح لصحة البطارية", color = Color.White, fontSize = 18.sp)
        Text("• تجنب الشحن إلى 100% لفترات طويلة.", color = Color(0xFF9AA4B2), fontSize = 14.sp)
        Text("• تجنب الحرارة العالية أثناء الشحن.", color = Color(0xFF9AA4B2), fontSize = 14.sp)
        Text("• استخدم شاحنًا وكابلًا جيدين.", color = Color(0xFF9AA4B2), fontSize = 14.sp)
    }
}

@Composable
fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Color.White, fontSize = 16.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
