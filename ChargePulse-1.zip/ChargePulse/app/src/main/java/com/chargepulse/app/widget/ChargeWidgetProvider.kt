package com.chargepulse.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import com.chargepulse.app.R
import java.util.Locale

class ChargeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        render(context, manager, ids)
    }

    companion object {
        fun update(context: Context, percent: Double, watts: Double) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ChargeWidgetProvider::class.java))
            render(context, manager, ids)
            val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
            prefs.edit().putFloat("percent", percent.toFloat()).putFloat("watts", watts.toFloat()).apply()
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
            val percent = prefs.getFloat("percent", 0f)
            val watts = prefs.getFloat("watts", 0f)
            val views = RemoteViews(context.packageName, R.layout.widget_charge)
            views.setTextViewText(R.id.widget_percent, String.format(Locale.US, "%.1f%%", percent))
            views.setTextViewText(R.id.widget_power, String.format(Locale.US, "%.1f W", watts))
            manager.updateAppWidget(ids, views)
        }
    }
}
