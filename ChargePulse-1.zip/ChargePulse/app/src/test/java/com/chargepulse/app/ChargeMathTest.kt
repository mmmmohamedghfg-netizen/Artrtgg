package com.chargepulse.app

import org.junit.Assert.assertEquals
import org.junit.Test
import com.chargepulse.app.monitor.ChargeMath

class ChargeMathTest {
    @Test
    fun smooth_firstValue_returnsNewValue() {
        assertEquals(100.0, ChargeMath.smooth(0.0, 100.0), 0.001)
    }

    @Test
    fun smooth_subsequentValue_returnsWeightedAverage() {
        assertEquals(85.0, ChargeMath.smooth(100.0, 50.0), 0.001)
    }

    @Test
    fun formatDuration_formatsHoursAndMinutes() {
        assertEquals("01:05", ChargeMath.formatDuration(65.0))
    }
}
