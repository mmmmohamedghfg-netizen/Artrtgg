package com.chargepulse.app.monitor

import java.util.Locale

object ChargeMath {
    fun smooth(old: Double, new: Double): Double {
        return if (old == 0.0) new else old * 0.7 + new * 0.3
    }

    fun formatDuration(minutes: Double): String {
        val total = minutes.toLong()
        return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
    }
}
