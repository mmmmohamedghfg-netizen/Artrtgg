package com.chargepulse.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.chargepulse.app.monitor.ChargeMonitorService
import com.chargepulse.app.monitor.MonitorRepository
import com.chargepulse.app.ui.ChargersScreen
import com.chargepulse.app.ui.DetailsScreen
import com.chargepulse.app.ui.HistoryScreen
import com.chargepulse.app.ui.HomeScreen
import com.chargepulse.app.ui.SettingsScreen
import com.chargepulse.app.ui.theme.ChargePulseTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChargePulseTheme {
                AppRoot()
            }
        }

        LaunchedEffect(Unit) {
            MonitorRepository.state.collect { state ->
                if (state.charging) {
                    startForegroundService(Intent(this@MainActivity, ChargeMonitorService::class.java))
                } else {
                    stopService(Intent(this@MainActivity, ChargeMonitorService::class.java))
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    Scaffold { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") {
                HomeScreen(
                    onDetails = { nav.navigate("details") },
                    onHistory = { nav.navigate("history") },
                    onChargers = { nav.navigate("chargers") },
                    onSettings = { nav.navigate("settings") }
                )
            }
            composable("details") { DetailsScreen(onBack = { nav.popBackStack() }) }
            composable("history") { HistoryScreen(onBack = { nav.popBackStack() }) }
            composable("chargers") { ChargersScreen(onBack = { nav.popBackStack() }) }
            composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
        }
    }
}
