package com.chargepulse.app.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {
    fun export(context: Context, sessions: List<ChargeSession>) {
        val dir = File(context.getExternalFilesDir("Documents"), "").apply { mkdirs() }
        val file = File(dir, "charge_history_" + System.currentTimeMillis() + ".csv")
        file.writeText("start,end,start_percent,end_percent,avg_watts,peak_watts,max_temp\n")
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        sessions.forEach { s ->
            file.appendText(
                listOf(
                    fmt.format(Date(s.startTime)),
                    s.endTime?.let { fmt.format(Date(it)) } ?: "",
                    s.startPercent,
                    s.endPercent ?: "",
                    s.avgWatts,
                    s.peakWatts,
                    s.maxTemp
                ).joinToString(",") + "\n"
            )
        }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "CSV"))
    }
}
