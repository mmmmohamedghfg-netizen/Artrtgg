package com.chargepulse.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ChargeSessionDao {
    @Insert suspend fun insert(session: ChargeSession): Long
    @Update suspend fun update(session: ChargeSession)
    @Query("SELECT * FROM sessions ORDER BY startTime DESC") fun observeAll(): Flow<List<ChargeSession>>
    @Query("DELETE FROM sessions") suspend fun clear()
}
