package com.chargepulse.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chargepulse.app.data.AppDatabase
import com.chargepulse.app.data.ChargerProfile
import com.chargepulse.app.monitor.MonitorRepository
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun ChargersScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val chargers by AppDatabase.get(context).chargerDao().observeAll()
        .collectAsState(initial = emptyList())
    val state by MonitorRepository.state.collectAsState()
    var name by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("رجوع") }
        Text("مقارنة الشواحن", color = Color.White, fontSize = 24.sp)
        Spacer(Modifier.height(12.dp))

        Button(onClick = { show = true }) { Text("إضافة شاحن") }
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chargers) { c ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0B0F)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(c.name, color = Color.White, fontSize = 16.sp)
                        Text(
                            String.format(Locale.US, "%.2f W", c.avgWatts),
                            color = Color(0xFFFF4D8D),
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }
    }

    if (show) {
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("اسم الشاحن") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        scope.launch {
                            AppDatabase.get(context).chargerDao().insert(
                                ChargerProfile(name = name, avgWatts = state.sessionAvgW, lastUsed = System.currentTimeMillis())
                            )
                        }
                    }
                    name = ""
                    show = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } }
        )
    }
}
