package com.chargepulse.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chargers")
data class ChargerProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val avgWatts: Double,
    val lastUsed: Long
)
