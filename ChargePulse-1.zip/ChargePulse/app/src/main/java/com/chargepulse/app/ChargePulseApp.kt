package com.chargepulse.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class ChargePulseApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            "charge_channel",
            getString(R.string.notification_channel),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
