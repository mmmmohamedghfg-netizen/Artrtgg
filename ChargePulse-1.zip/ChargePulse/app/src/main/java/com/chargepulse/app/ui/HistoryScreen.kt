package com.chargepulse.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chargepulse.app.data.AppDatabase
import com.chargepulse.app.data.CsvExporter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val sessions by AppDatabase.get(context).sessionDao().observeAll()
        .collectAsState(initial = emptyList())

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("رجوع") }
            TextButton(onClick = { CsvExporter.export(context, sessions) }) { Text("تصدير CSV") }
        }
        Spacer(Modifier.height(8.dp))
        Text("سجل الشحن", color = Color.White, fontSize = 24.sp)
        Spacer(Modifier.height(12.dp))

        if (sessions.isEmpty()) {
            Text("لا توجد جلسات بعد", color = Color(0xFF9AA4B2))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sessions) { s ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0B0F)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            val fmt = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US) }
                            Text("البداية: " + fmt.format(Date(s.startTime)), color = Color.White, fontSize = 14.sp)
                            Text("النهاية: " + (s.endTime?.let { fmt.format(Date(it)) } ?: "--"), color = Color.White, fontSize = 14.sp)
                            Text("المتوسط: " + String.format(Locale.US, "%.2f W", s.avgWatts), color = Color(0xFFFF4D8D), fontSize = 14.sp)
                            Text("الأعلى: " + String.format(Locale.US, "%.2f W", s.peakWatts), color = Color(0xFFFFB300), fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
