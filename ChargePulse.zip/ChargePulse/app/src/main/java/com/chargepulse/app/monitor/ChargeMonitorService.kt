package com.chargepulse.app.monitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.chargepulse.app.MainActivity
import com.chargepulse.app.R
import com.chargepulse.app.data.AppDatabase
import com.chargepulse.app.data.ChargeSession
import com.chargepulse.app.widget.ChargeWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ChargeMonitorService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var sessionId: Long = -1
    private var sessionStart = 0L
    private var sessionEnergyWh = 0.0
    private var sessionPeakW = 0.0
    private var sessionSamples = 0
    private var sessionWattsSum = 0.0
    private var slowSince = 0L
    private var alerted80 = false
    private var alertedTemp = false
    private var alertedFull = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = buildNotification(0.0, 0.0)
        ServiceCompat.startForeground(
            this, 1, notification,
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        scope.launch {
            while (isActive) {
                update()
                delay(1000)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun update() {
        val snapshot = BatteryReader.read(this)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val threshold = prefs.getInt("alert_percent", 80)

        if (snapshot.charging && sessionId == -1) startSession(snapshot)
        if (!snapshot.charging && sessionId != -1) endSession(snapshot)

        if (snapshot.charging) {
            sessionEnergyWh += snapshot.watts / 3600.0
            sessionWattsSum += snapshot.watts
            sessionSamples++
            if (snapshot.watts > sessionPeakW) sessionPeakW = snapshot.watts

            if (snapshot.watts < 5.0) {
                if (slowSince == 0L) slowSince = System.currentTimeMillis()
            } else slowSince = 0L
        }

        val elapsedMin = if (snapshot.charging && sessionStart > 0)
            (System.currentTimeMillis() - sessionStart) / 60000.0 else 0.0
        val avgW = if (sessionSamples > 0) sessionWattsSum / sessionSamples else 0.0
        val remainingMah = if (snapshot.chargeCounterUah > 0)
            (snapshot.chargeCounterUah / 1000.0) * (100.0 - snapshot.percent) / 100.0 else 0.0
        val estimateMinutes = if (snapshot.charging && snapshot.currentMa > 0)
            remainingMah / snapshot.currentMa * 60.0 else 0.0
        val slow = snapshot.charging && slowSince > 0 &&
                System.currentTimeMillis() - slowSince > 120_000

        MonitorRepository.update {
            it.copy(
                percent = snapshot.percent,
                watts = snapshot.watts,
                voltage = snapshot.voltage,
                currentMa = snapshot.currentMa,
                temperature = snapshot.temperature,
                charging = snapshot.charging,
                full = snapshot.full,
                plugged = snapshot.plugged,
                status = snapshot.status,
                health = snapshot.health,
                technology = snapshot.technology,
                chargeCounterUah = snapshot.chargeCounterUah,
                sessionStart = sessionStart,
                sessionEnergyWh = sessionEnergyWh,
                sessionPeakW = sessionPeakW,
                sessionAvgW = avgW,
                estimateMinutes = estimateMinutes,
                slowWarning = slow,
                history = (it.history + snapshot.watts).takeLast(60)
            )
        }

        updateWidget(snapshot)
        updateNotification(snapshot)

        if (snapshot.charging && !alerted80 && snapshot.percent >= threshold) {
            alerted80 = true
            notifyAlert("وصلت البطارية إلى " + threshold + "%")
        }
        if (snapshot.charging && !alertedTemp && snapshot.temperature >= 45.0) {
            alertedTemp = true
            notifyAlert("حرارة البطارية مرتفعة")
        }
        if (snapshot.full && !alertedFull) {
            alertedFull = true
            notifyAlert("اكتمل شحن البطارية")
        }
    }

    private fun startSession(snapshot: BatterySnapshot) {
        sessionStart = System.currentTimeMillis()
        sessionEnergyWh = 0.0
        sessionPeakW = 0.0
        sessionSamples = 0
        sessionWattsSum = 0.0
        slowSince = 0L
        alerted80 = false
        alertedTemp = false
        alertedFull = false
        scope.launch {
            val id = AppDatabase.get(applicationContext).sessionDao()
                .insert(ChargeSession(startTime = sessionStart, startPercent = snapshot.percent.toInt()))
            sessionId = id
        }
    }

    private fun endSession(snapshot: BatterySnapshot) {
        val id = sessionId
        val start = sessionStart
        val energy = sessionEnergyWh
        val peak = sessionPeakW
        val samples = sessionSamples
        val sum = sessionWattsSum
        sessionId = -1
        if (id == -1L) return
        scope.launch {
            val dao = AppDatabase.get(applicationContext).sessionDao()
            val session = dao.observeAll().let { }
            dao.update(
                ChargeSession(
                    id = id,
                    startTime = start,
                    endTime = System.currentTimeMillis(),
                    startPercent = 0,
                    endPercent = snapshot.percent.toInt(),
                    avgWatts = if (samples > 0) sum / samples else 0.0,
                    peakWatts = peak,
                    maxTemp = snapshot.temperature
                )
            )
        }
    }

    private fun updateWidget(snapshot: BatterySnapshot) {
        ChargeWidgetProvider.update(this, snapshot.percent, snapshot.watts)
    }

    private fun updateNotification(snapshot: BatterySnapshot) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, buildNotification(snapshot.percent, snapshot.watts))
    }

    private fun buildNotification(percent: Double, watts: Double): Notification {
        val intent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "charge_channel")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(
                String.format(java.util.Locale.US, "%.1f%% • %.1f W", percent, watts)
            )
            .setOngoing(true)
            .setContentIntent(intent)
            .build()
    }

    private fun notifyAlert(message: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(this, "charge_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(message)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), notification)
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            "charge_channel",
            getString(R.string.notification_channel),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
