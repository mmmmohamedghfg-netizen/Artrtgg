package com.chargepulse.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChargerProfileDao {
    @Insert suspend fun insert(profile: ChargerProfile)
    @Query("SELECT * FROM chargers ORDER BY avgWatts DESC") fun observeAll(): Flow<List<ChargerProfile>>
    @Query("DELETE FROM chargers WHERE id = :id") suspend fun delete(id: Long)
}
